//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.

// VERSION
#define DLL_VERSION_MAJ_LO 1
#define DLL_VERSION_MIN_HI 1
#define DLL_VERSION_MIN_LO 3
#define DLL_VERSION_PATCHL 0

// VERSION STRING
#define DLL_VERSION_STR_F1(X)         #X
#define DLL_VERSION_STR_F2(W,X,Y,Z)   DLL_VERSION_STR_F1(W.X.Y.Z)
#define DLL_VERSION_STR_F3(W,X,Y,Z)   DLL_VERSION_STR_F2(W,X,Y,Z)
#define DLL_VERSION_STRING            DLL_VERSION_STR_F3(DLL_VERSION_MAJ_LO,DLL_VERSION_MIN_HI,DLL_VERSION_MIN_LO,DLL_VERSION_PATCHL)


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
